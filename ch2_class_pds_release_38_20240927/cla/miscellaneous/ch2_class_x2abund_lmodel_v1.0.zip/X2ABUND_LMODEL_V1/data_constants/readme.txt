Sources for the data files

1. atomicweight.txt - from prince's data folder
2. fluores_yield.txt - from prince's data folder
3. kalpha_be_density_kbeta.txt - from prince's data folder
4. form_factors - from prince's data folder. These are originally from Hubbell et al 1975
5. ffast - downloaded from ffast website (part of nist)
6. xcom - downloaded from xcom website (part of nist)
7. fnt_frel.txt -  made this file using values from ffast database. Note: sign change is done (ref. Chantler et al)
